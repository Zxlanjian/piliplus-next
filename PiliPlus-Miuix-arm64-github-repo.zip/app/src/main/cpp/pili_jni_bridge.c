/*
 * pili_jni_bridge.c
 *
 * JNI wrapper bridging Kotlin Multiplatform (com.piliplus.miuix.PiliAsmCore)
 * to the ARM64 (arm64-v8a) assembly functions defined in pili_core_arm64.S.
 */

#include <jni.h>
#include <stdint.h>
#include <stddef.h>
#include <stdlib.h>
#include <string.h>

extern int wbi_permute_mixin_key_asm(const uint8_t *raw_key_64, uint8_t *out_mixin_32);
extern uint64_t fnv1a_hash64_asm(const uint8_t *data, size_t len);
extern size_t filter_danmaku_timestamps_neon(
    const uint32_t *timestamps_ms,
    size_t count,
    uint32_t window_start_ms,
    uint32_t window_end_ms,
    uint8_t *out_visibility_mask
);
extern int allocate_danmaku_tracks_asm(
    const int32_t *danmaku_times_ms,
    int32_t count,
    int32_t max_tracks,
    int32_t min_gap_ms,
    int32_t *track_avail_ms,
    int32_t *out_assigned_tracks
);
extern void normalize_high_energy_bar_neon(
    const float *raw_buckets,
    float *out_norm_buckets,
    size_t count
);
extern int64_t compute_gesture_seek_ms_asm(
    int64_t current_pos_ms,
    int64_t duration_ms,
    int32_t drag_delta_px,
    int32_t viewport_width_px,
    int64_t full_swipe_span_ms
);
extern void sort_comment_keys_asm(
    uint64_t *keys,
    int32_t *indices,
    int32_t count
);

JNIEXPORT jint JNICALL
Java_com_piliplus_miuix_PiliAsmCore_permuteWbiMixinKey(
    JNIEnv *env,
    jobject thiz,
    jbyteArray raw_key_bytes,
    jbyteArray out_mixin_bytes
) {
    (void)thiz;
    if (raw_key_bytes == NULL || out_mixin_bytes == NULL) return -1;

    jsize raw_len = (*env)->GetArrayLength(env, raw_key_bytes);
    jsize out_len = (*env)->GetArrayLength(env, out_mixin_bytes);
    if (raw_len < 64 || out_len < 32) return -2;

    jbyte *raw_ptr = (*env)->GetByteArrayElements(env, raw_key_bytes, NULL);
    jbyte *out_ptr = (*env)->GetByteArrayElements(env, out_mixin_bytes, NULL);
    if (raw_ptr == NULL || out_ptr == NULL) {
        if (raw_ptr != NULL) (*env)->ReleaseByteArrayElements(env, raw_key_bytes, raw_ptr, JNI_ABORT);
        if (out_ptr != NULL) (*env)->ReleaseByteArrayElements(env, out_mixin_bytes, out_ptr, JNI_ABORT);
        return -3;
    }

    int status = wbi_permute_mixin_key_asm((const uint8_t *)raw_ptr, (uint8_t *)out_ptr);

    (*env)->ReleaseByteArrayElements(env, raw_key_bytes, raw_ptr, JNI_ABORT);
    (*env)->ReleaseByteArrayElements(env, out_mixin_bytes, out_ptr, 0);
    return (jint)status;
}

JNIEXPORT jlong JNICALL
Java_com_piliplus_miuix_PiliAsmCore_fnv1aHash64(
    JNIEnv *env,
    jobject thiz,
    jbyteArray data
) {
    (void)thiz;
    if (data == NULL) return 0LL;

    jsize len = (*env)->GetArrayLength(env, data);
    jbyte *ptr = (*env)->GetByteArrayElements(env, data, NULL);
    if (ptr == NULL) return 0LL;

    uint64_t hash = fnv1a_hash64_asm((const uint8_t *)ptr, (size_t)len);
    (*env)->ReleaseByteArrayElements(env, data, ptr, JNI_ABORT);
    return (jlong)hash;
}

JNIEXPORT jint JNICALL
Java_com_piliplus_miuix_PiliAsmCore_filterDanmakuWindowNeon(
    JNIEnv *env,
    jobject thiz,
    jintArray timestamps_ms,
    jint window_start_ms,
    jint window_end_ms,
    jbyteArray out_mask
) {
    (void)thiz;
    if (timestamps_ms == NULL || out_mask == NULL) return 0;

    jsize count = (*env)->GetArrayLength(env, timestamps_ms);
    jsize mask_len = (*env)->GetArrayLength(env, out_mask);
    if (count <= 0 || mask_len < count) return 0;

    jint *ts_ptr = (*env)->GetIntArrayElements(env, timestamps_ms, NULL);
    jbyte *mask_ptr = (*env)->GetByteArrayElements(env, out_mask, NULL);
    if (ts_ptr == NULL || mask_ptr == NULL) {
        if (ts_ptr != NULL) (*env)->ReleaseIntArrayElements(env, timestamps_ms, ts_ptr, JNI_ABORT);
        if (mask_ptr != NULL) (*env)->ReleaseByteArrayElements(env, out_mask, mask_ptr, JNI_ABORT);
        return 0;
    }

    size_t processed = filter_danmaku_timestamps_neon(
        (const uint32_t *)ts_ptr,
        (size_t)count,
        (uint32_t)window_start_ms,
        (uint32_t)window_end_ms,
        (uint8_t *)mask_ptr
    );

    (*env)->ReleaseIntArrayElements(env, timestamps_ms, ts_ptr, JNI_ABORT);
    (*env)->ReleaseByteArrayElements(env, out_mask, mask_ptr, 0);
    return (jint)processed;
}

JNIEXPORT jint JNICALL
Java_com_piliplus_miuix_PiliAsmCore_allocateDanmakuTracks(
    JNIEnv *env,
    jobject thiz,
    jintArray danmaku_times_ms,
    jint max_tracks,
    jint min_gap_ms,
    jintArray out_assigned_tracks
) {
    (void)thiz;
    if (danmaku_times_ms == NULL || out_assigned_tracks == NULL || max_tracks <= 0) return 0;

    jsize count = (*env)->GetArrayLength(env, danmaku_times_ms);
    jsize out_len = (*env)->GetArrayLength(env, out_assigned_tracks);
    if (count <= 0 || out_len < count) return 0;

    int32_t *track_avail = (int32_t *)calloc((size_t)max_tracks, sizeof(int32_t));
    if (track_avail == NULL) return 0;
    for (int i = 0; i < max_tracks; i++) {
        track_avail[i] = -100000;
    }

    jint *times_ptr = (*env)->GetIntArrayElements(env, danmaku_times_ms, NULL);
    jint *out_ptr = (*env)->GetIntArrayElements(env, out_assigned_tracks, NULL);
    int placed = 0;

    if (times_ptr != NULL && out_ptr != NULL) {
        placed = allocate_danmaku_tracks_asm(
            (const int32_t *)times_ptr,
            (int32_t)count,
            (int32_t)max_tracks,
            (int32_t)min_gap_ms,
            track_avail,
            (int32_t *)out_ptr
        );
    }

    if (times_ptr != NULL) (*env)->ReleaseIntArrayElements(env, danmaku_times_ms, times_ptr, JNI_ABORT);
    if (out_ptr != NULL) (*env)->ReleaseIntArrayElements(env, out_assigned_tracks, out_ptr, 0);
    free(track_avail);
    return (jint)placed;
}

JNIEXPORT void JNICALL
Java_com_piliplus_miuix_PiliAsmCore_normalizeHighEnergyBarNeon(
    JNIEnv *env,
    jobject thiz,
    jfloatArray raw_buckets,
    jfloatArray out_norm_buckets
) {
    (void)thiz;
    if (raw_buckets == NULL || out_norm_buckets == NULL) return;

    jsize count = (*env)->GetArrayLength(env, raw_buckets);
    jsize out_len = (*env)->GetArrayLength(env, out_norm_buckets);
    if (count <= 0 || out_len < count) return;

    jfloat *raw_ptr = (*env)->GetFloatArrayElements(env, raw_buckets, NULL);
    jfloat *out_ptr = (*env)->GetFloatArrayElements(env, out_norm_buckets, NULL);
    if (raw_ptr != NULL && out_ptr != NULL) {
        normalize_high_energy_bar_neon((const float *)raw_ptr, (float *)out_ptr, (size_t)count);
    }
    if (raw_ptr != NULL) (*env)->ReleaseFloatArrayElements(env, raw_buckets, raw_ptr, JNI_ABORT);
    if (out_ptr != NULL) (*env)->ReleaseFloatArrayElements(env, out_norm_buckets, out_ptr, 0);
}

JNIEXPORT jlong JNICALL
Java_com_piliplus_miuix_PiliAsmCore_computeGestureSeekMs(
    JNIEnv *env,
    jobject thiz,
    jlong current_pos_ms,
    jlong duration_ms,
    jint drag_delta_px,
    jint viewport_width_px,
    jlong full_swipe_span_ms
) {
    (void)env;
    (void)thiz;
    return (jlong)compute_gesture_seek_ms_asm(
        (int64_t)current_pos_ms,
        (int64_t)duration_ms,
        (int32_t)drag_delta_px,
        (int32_t)viewport_width_px,
        (int64_t)full_swipe_span_ms
    );
}

JNIEXPORT void JNICALL
Java_com_piliplus_miuix_PiliAsmCore_sortCommentKeys(
    JNIEnv *env,
    jobject thiz,
    jlongArray keys,
    jintArray indices
) {
    (void)thiz;
    if (keys == NULL || indices == NULL) return;

    jsize count = (*env)->GetArrayLength(env, keys);
    jsize idx_len = (*env)->GetArrayLength(env, indices);
    if (count <= 1 || idx_len < count) return;

    jlong *keys_ptr = (*env)->GetLongArrayElements(env, keys, NULL);
    jint *idx_ptr = (*env)->GetIntArrayElements(env, indices, NULL);
    if (keys_ptr != NULL && idx_ptr != NULL) {
        sort_comment_keys_asm((uint64_t *)keys_ptr, (int32_t *)idx_ptr, (int32_t)count);
    }
    if (keys_ptr != NULL) (*env)->ReleaseLongArrayElements(env, keys, keys_ptr, 0);
    if (idx_ptr != NULL) (*env)->ReleaseIntArrayElements(env, indices, idx_ptr, 0);
}