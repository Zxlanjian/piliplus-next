package com.piliplus.miuix

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.MutableState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay
import kotlinx.serialization.Serializable
import top.yukonga.miuix.kmp.basic.Button
import top.yukonga.miuix.kmp.basic.Card
import top.yukonga.miuix.kmp.basic.InputField
import top.yukonga.miuix.kmp.basic.NavigationBar
import top.yukonga.miuix.kmp.basic.NavigationBarItem
import top.yukonga.miuix.kmp.basic.PullToRefresh
import top.yukonga.miuix.kmp.basic.Scaffold
import top.yukonga.miuix.kmp.basic.Slider
import top.yukonga.miuix.kmp.basic.SmallTitle
import top.yukonga.miuix.kmp.basic.TabRowWithContour
import top.yukonga.miuix.kmp.basic.Text
import top.yukonga.miuix.kmp.basic.TextButton
import top.yukonga.miuix.kmp.basic.TopAppBar
import top.yukonga.miuix.kmp.basic.rememberPullToRefreshState
import top.yukonga.miuix.kmp.extra.OverlayBottomSheet
import top.yukonga.miuix.kmp.extra.OverlayDialog
import top.yukonga.miuix.kmp.icon.MiuixIcons
import top.yukonga.miuix.kmp.icon.icons.basic.Search
import top.yukonga.miuix.kmp.icon.icons.extended.Home
import top.yukonga.miuix.kmp.icon.icons.extended.Settings
import top.yukonga.miuix.kmp.nav.core.NavDisplay
import top.yukonga.miuix.kmp.nav.core.NavKey
import top.yukonga.miuix.kmp.nav.core.rememberNavBackStack
import top.yukonga.miuix.kmp.preference.ArrowPreference
import top.yukonga.miuix.kmp.preference.RadioButtonPreference
import top.yukonga.miuix.kmp.preference.SwitchPreference
import top.yukonga.miuix.kmp.theme.MiuixTheme
import top.yukonga.miuix.kmp.utils.MiuixPopupUtils.Companion.MiuixPopupHost
import kotlin.math.abs

/**
 * JNI Bridge to the ARM64 (arm64-v8a) Assembly Core (libpilicore_asm.so).
 * Provides graceful pure-Kotlin fallbacks during JVM preview if native SO is not yet loaded.
 */
object PiliAsmCore {
    private var nativeLoaded = false

    init {
        try {
            System.loadLibrary("pilicore_asm")
            nativeLoaded = true
        } catch (_: Throwable) {
            nativeLoaded = false
        }
    }

    external fun permuteWbiMixinKey(rawKeyBytes: ByteArray, outMixinBytes: ByteArray): Int
    external fun fnv1aHash64(data: ByteArray): Long
    external fun filterDanmakuWindowNeon(
        timestampsMs: IntArray,
        windowStartMs: Int,
        windowEndMs: Int,
        outMask: ByteArray
    ): Int

    external fun allocateDanmakuTracks(
        danmakuTimesMs: IntArray,
        maxTracks: Int,
        minGapMs: Int,
        outAssignedTracks: IntArray
    ): Int

    external fun normalizeHighEnergyBarNeon(
        rawBuckets: FloatArray,
        outNormBuckets: FloatArray
    )

    external fun computeGestureSeekMs(
        currentPosMs: Long,
        durationMs: Long,
        dragDeltaPx: Int,
        viewportWidthPx: Int,
        fullSwipeSpanMs: Long
    ): Long

    external fun sortCommentKeys(
        keys: LongArray,
        indices: IntArray
    )

    fun safeNormalizeHighEnergy(rawBuckets: FloatArray): FloatArray {
        val out = FloatArray(rawBuckets.size)
        if (nativeLoaded) {
            normalizeHighEnergyBarNeon(rawBuckets, out)
        } else {
            val maxVal = (rawBuckets.maxOrNull() ?: 1f).coerceAtLeast(1e-6f)
            for (i in rawBuckets.indices) {
                out[i] = (rawBuckets[i] / maxVal).coerceIn(0f, 1f)
            }
        }
        return out
    }

    fun safeFilterAndLayoutDanmaku(
        items: List<DanmakuItem>,
        currentPosMs: Long,
        windowSpanMs: Int = 6000,
        maxTracks: Int = 6
    ): List<Pair<DanmakuItem, Int>> {
        if (items.isEmpty()) return emptyList()
        val count = items.size
        val timestamps = IntArray(count) { items[it].timeMs }
        val mask = ByteArray(count)
        val startMs = (currentPosMs - 500L).coerceAtLeast(0L).toInt()
        val endMs = (currentPosMs + windowSpanMs).toInt()

        if (nativeLoaded) {
            filterDanmakuWindowNeon(timestamps, startMs, endMs, mask)
        } else {
            for (i in 0 until count) {
                mask[i] = if (timestamps[i] in startMs..endMs) 0xFF.toByte() else 0
            }
        }

        val visibleItems = ArrayList<DanmakuItem>()
        for (i in 0 until count) {
            if (mask[i] != 0.toByte()) {
                visibleItems.add(items[i])
            }
        }
        if (visibleItems.isEmpty()) return emptyList()

        val visTimes = IntArray(visibleItems.size) { visibleItems[it].timeMs }
        val assignedTracks = IntArray(visibleItems.size) { -1 }

        if (nativeLoaded) {
            allocateDanmakuTracks(visTimes, maxTracks, 1100, assignedTracks)
        } else {
            val trackAvail = IntArray(maxTracks) { -100000 }
            for (i in visTimes.indices) {
                val tMs = visTimes[i]
                for (t in 0 until maxTracks) {
                    if (tMs >= trackAvail[t]) {
                        assignedTracks[i] = t
                        trackAvail[t] = tMs + 1100
                        break
                    }
                }
            }
        }

        return visibleItems.mapIndexedNotNull { idx, dm ->
            val track = assignedTracks[idx]
            if (track >= 0) dm to track else null
        }
    }

    fun safeComputeGestureSeekMs(
        currentPosMs: Long,
        durationMs: Long,
        dragDeltaPx: Int,
        viewportWidthPx: Int,
        fullSwipeSpanMs: Long = 90_000L
    ): Long {
        if (nativeLoaded) {
            return computeGestureSeekMs(currentPosMs, durationMs, dragDeltaPx, viewportWidthPx, fullSwipeSpanMs)
        }
        if (viewportWidthPx <= 0) return currentPosMs
        val deltaMs = (dragDeltaPx.toLong() * fullSwipeSpanMs) / viewportWidthPx.toLong()
        return (currentPosMs + deltaMs).coerceIn(0L, durationMs)
    }

    fun safeSortComments(comments: List<CommentItem>, sortByHot: Boolean): List<CommentItem> {
        val n = comments.size
        if (n <= 1) return comments
        val keys = LongArray(n) { i ->
            val c = comments[i]
            val primary = if (sortByHot) c.likes.toLong() else c.timestampSec
            val secondary = if (sortByHot) (c.timestampSec and 0xFFFFFFFFL) else (c.likes.toLong() and 0xFFFFFFFFL)
            (primary shl 32) or secondary
        }
        val indices = IntArray(n) { it }
        if (nativeLoaded) {
            sortCommentKeys(keys, indices)
            return indices.map { comments[it] }
        }
        return comments.sortedWith(
            if (sortByHot) compareByDescending<CommentItem> { it.isPinned }.thenByDescending { it.likes }
            else compareByDescending<CommentItem> { it.isPinned }.thenByDescending { it.timestampSec }
        )
    }
}

/* ============================================================================
 * Navigation Routes & Domain Models
 * ============================================================================ */

@Serializable
sealed interface PiliRoute : NavKey {
    @Serializable
    data object Main : PiliRoute

    @Serializable
    data class VideoDetail(
        val bvid: String,
        val title: String,
        val author: String,
        val durationMs: Long = 860_000L
    ) : PiliRoute
}

data class VideoCardItem(
    val bvid: String,
    val title: String,
    val upName: String,
    val viewsText: String,
    val durationText: String,
    val durationMs: Long = 860_000L
)

data class VideoEpisodePart(
    val page: Int,
    val cid: Long,
    val partTitle: String,
    val durationMs: Long
)

data class DanmakuItem(
    val id: Long,
    val timeMs: Int,
    val text: String,
    val uidHash: Long,
    val isVipColor: Boolean = false,
    val likes: Int = 0
)

data class SubReplyItem(
    val rpid: Long,
    val userName: String,
    val level: Int,
    val content: String,
    val timeText: String,
    val likes: Int,
    val replyToUser: String? = null
)

data class CommentItem(
    val rpid: Long,
    val userName: String,
    val level: Int,
    val isUp: Boolean,
    val isPinned: Boolean,
    val content: String,
    val timeText: String,
    val timestampSec: Long,
    val likes: Int,
    val imageNoteTag: String? = null,
    val subReplies: List<SubReplyItem> = emptyList()
)

data class DynamicPostItem(
    val dynId: String,
    val category: String, // "video", "bangumi", "article"
    val authorName: String,
    val pubTimeText: String,
    val topicTag: String?,
    val contentText: String,
    val attachedVideo: VideoCardItem? = null,
    val imageCount: Int = 0,
    val likes: Int,
    val reposts: Int,
    val comments: List<CommentItem> = emptyList()
)

/* ============================================================================
 * Root App Entry
 * ============================================================================ */

@Composable
fun PiliMiuixApp() {
    MiuixTheme {
        val backStack = rememberNavBackStack<PiliRoute>(PiliRoute.Main)

        NavDisplay(
            backStack = backStack,
            onBack = { backStack.removeLastOrNull() }
        ) {
            entry<PiliRoute.Main> {
                MainContainerScreen(
                    onVideoClick = { item ->
                        backStack.add(
                            PiliRoute.VideoDetail(
                                bvid = item.bvid,
                                title = item.title,
                                author = item.upName,
                                durationMs = item.durationMs
                            )
                        )
                    }
                )
            }
            entry<PiliRoute.VideoDetail> { route ->
                VideoDetailScreen(
                    bvid = route.bvid,
                    title = route.title,
                    author = route.author,
                    initialDurationMs = route.durationMs,
                    onBack = { backStack.removeLastOrNull() },
                    onRelatedVideoClick = { nextVideo ->
                        backStack.add(
                            PiliRoute.VideoDetail(
                                bvid = nextVideo.bvid,
                                title = nextVideo.title,
                                author = nextVideo.upName,
                                durationMs = nextVideo.durationMs
                            )
                        )
                    }
                )
            }
        }
    }
}

/* ============================================================================
 * Main 4-Tab Container (首页推荐 / 动态 / 热门与番剧 / 个人与设置)
 * ============================================================================ */

@Composable
fun MainContainerScreen(
    onVideoClick: (VideoCardItem) -> Unit
) {
    var selectedTab by remember { mutableIntStateOf(0) }
    var searchQuery by remember { mutableStateOf("") }

    Scaffold(
        topBar = {
            TopAppBar(
                title = when (selectedTab) {
                    0 -> "PiliPlus · 推荐"
                    1 -> "关注动态"
                    2 -> "热门与番剧"
                    else -> "个人与设置"
                }
            )
        },
        bottomBar = {
            NavigationBar {
                NavigationBarItem(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    icon = MiuixIcons.Extended.Home,
                    label = "首页"
                )
                NavigationBarItem(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    icon = MiuixIcons.Basic.Search,
                    label = "动态"
                )
                NavigationBarItem(
                    selected = selectedTab == 2,
                    onClick = { selectedTab = 2 },
                    icon = MiuixIcons.Basic.Search,
                    label = "热门"
                )
                NavigationBarItem(
                    selected = selectedTab == 3,
                    onClick = { selectedTab = 3 },
                    icon = MiuixIcons.Extended.Settings,
                    label = "设置"
                )
            }
        },
        popupHost = { MiuixPopupHost() }
    ) { innerPadding ->
        when (selectedTab) {
            0 -> RecommendFeedScreen(
                contentPadding = innerPadding,
                searchQuery = searchQuery,
                onSearchQueryChange = { searchQuery = it },
                onVideoClick = onVideoClick
            )
            1 -> DynamicFeedScreen(
                contentPadding = innerPadding,
                onVideoClick = onVideoClick
            )
            2 -> HotAndBangumiScreen(
                contentPadding = innerPadding,
                onVideoClick = onVideoClick
            )
            3 -> SettingsScreen(contentPadding = innerPadding)
        }
    }
}

/* ============================================================================
 * Module 1 (Priority): Video Detail & ARM64-Accelerated Video Player + Comments
 * ============================================================================ */

@Composable
fun VideoDetailScreen(
    bvid: String,
    title: String,
    author: String,
    initialDurationMs: Long,
    onBack: () -> Unit,
    onRelatedVideoClick: (VideoCardItem) -> Unit
) {
    // Video playback states
    var isPlaying by remember { mutableStateOf(true) }
    var isFullscreen by remember { mutableStateOf(false) }
    var currentPosMs by remember { mutableLongStateOf(12_000L) }
    var durationMs by remember { mutableLongStateOf(initialDurationMs) }
    var playbackSpeed by remember { mutableFloatStateOf(1.0f) }
    var isLongPress2x by remember { mutableStateOf(false) }
    var brightnessLevel by remember { mutableFloatStateOf(0.65f) }
    var volumeLevel by remember { mutableFloatStateOf(0.75f) }
    var gestureOverlayText by remember { mutableStateOf<String?>(null) }

    // Stream & player presets
    var selectedQuality by remember { mutableStateOf("1080P 60帧") }
    var selectedAudioQuality by remember { mutableStateOf("192K 高品质") }
    var selectedCodec by remember { mutableStateOf("HEVC (H.265)") }
    var selectedAspectRatio by remember { mutableStateOf("16:9 适应") }
    var danmakuEnabled by remember { mutableStateOf(true) }
    var sponsorBlockSkippedNotice by remember { mutableStateOf<String?>(null) }

    // Multi-part (分P) episodes
    val episodes = remember(bvid) {
        listOf(
            VideoEpisodePart(1, 1001L, "P1 · 架构总览与 AArch64 寄存器约定", 860_000L),
            VideoEpisodePart(2, 1002L, "P2 · NEON 128-bit 向量化弹幕碰撞检测", 740_000L),
            VideoEpisodePart(3, 1003L, "P3 · Compose Miuix 手势状态机与高帧率渲染", 920_000L)
        )
    }
    var currentPartIndex by remember { mutableIntStateOf(0) }

    // Interaction states (点赞 / 投币 / 收藏 / 追番)
    var liked by remember { mutableStateOf(false) }
    var likeCount by remember { mutableIntStateOf(4820) }
    var coinedCount by remember { mutableIntStateOf(0) }
    var favorited by remember { mutableStateOf(false) }

    // Sub-tab inside VideoDetail: 0 = 简介与选集, 1 = 评论区
    var detailTabIndex by remember { mutableIntStateOf(0) }

    // Popups & BottomSheets
    val showPlayerSettingsSheet = remember { mutableStateOf(false) }
    val selectedDanmakuForAction = remember { mutableStateOf<DanmakuItem?>(null) }

    // High-energy bar buckets normalized via ARM64 NEON SIMD
    val normalizedHighEnergy = remember(bvid, currentPartIndex) {
        val raw = floatArrayOf(
            12f, 18f, 25f, 40f, 95f, 82f, 34f, 28f,
            45f, 68f, 110f, 125f, 90f, 52f, 30f, 60f,
            88f, 140f, 115f, 70f, 48f, 35f, 62f, 98f
        )
        PiliAsmCore.safeNormalizeHighEnergy(raw)
    }

    // Sample danmaku pool filtered & assigned to tracks via ARM64 NEON + Assembly
    val danmakuPool = remember(bvid) {
        listOf(
            DanmakuItem(1L, 12_500, "前方高能！ARM64 NEON 向量化起飞", 0x101L, isVipColor = true, likes = 42),
            DanmakuItem(2L, 13_100, "Miuix 这个圆角和毛玻璃质感太丝滑了", 0x102L, isVipColor = false, likes = 19),
            DanmakuItem(3L, 13_400, "双击快进、长按2倍速、垂直滑全屏全都齐了", 0x103L, isVipColor = false, likes = 27),
            DanmakuItem(4L, 14_200, "SponsorBlock 空降成功，感谢 UP 主", 0x104L, isVipColor = true, likes = 65),
            DanmakuItem(5L, 15_000, "高能进度条峰值直接定位名场面", 0x105L, isVipColor = false, likes = 31),
            DanmakuItem(6L, 16_200, "汇编手写 ShellSort 排评论区，零 GC 开销", 0x106L, isVipColor = true, likes = 53)
        )
    }

    // Playback clock tick + SponsorBlock segment auto-skip simulation
    LaunchedEffect(isPlaying, playbackSpeed, isLongPress2x, currentPartIndex) {
        while (isPlaying) {
            delay(200L)
            val effectiveSpeed = if (isLongPress2x) 2.0f else playbackSpeed
            val stepMs = (200f * effectiveSpeed).toLong()
            val nextPos = (currentPosMs + stepMs).coerceAtMost(durationMs)
            // Simulate SponsorBlock / 番剧片头跳过 around 25.0s..28.0s
            if (nextPos in 25_000L..27_500L) {
                currentPosMs = 28_000L
                sponsorBlockSkippedNotice = "已通过 SponsorBlock 自动跳过片头/恰饭片段 (00:25 → 00:28)"
            } else {
                currentPosMs = if (nextPos >= durationMs) 10_000L else nextPos
            }
        }
    }

    val activeDanmakuTracks = remember(currentPosMs, danmakuEnabled) {
        if (!danmakuEnabled) emptyList()
        else PiliAsmCore.safeFilterAndLayoutDanmaku(danmakuPool, currentPosMs)
    }

    Scaffold(
        topBar = {
            if (!isFullscreen) {
                TopAppBar(
                    title = "$bvid · P${currentPartIndex + 1}"
                )
            }
        },
        popupHost = { MiuixPopupHost() }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(if (isFullscreen) PaddingValues(0.dp) else innerPadding)
        ) {
            // 1. Interactive Video Player Box with Full Gesture & Danmaku Support
            VideoPlayerMiuixBox(
                bvid = bvid,
                partTitle = episodes[currentPartIndex].partTitle,
                isPlaying = isPlaying,
                isFullscreen = isFullscreen,
                currentPosMs = currentPosMs,
                durationMs = durationMs,
                effectiveSpeed = if (isLongPress2x) 2.0f else playbackSpeed,
                isLongPress2x = isLongPress2x,
                brightness = brightnessLevel,
                volume = volumeLevel,
                selectedQuality = selectedQuality,
                selectedCodec = selectedCodec,
                danmakuEnabled = danmakuEnabled,
                activeDanmakuTracks = activeDanmakuTracks,
                highEnergyCurve = normalizedHighEnergy,
                gestureOverlayText = gestureOverlayText,
                onTogglePlay = { isPlaying = !isPlaying },
                onSeekTo = { targetMs -> currentPosMs = targetMs.coerceIn(0L, durationMs) },
                onLongPress2xChange = { active ->
                    isLongPress2x = active
                    gestureOverlayText = if (active) "倍速播放中: 2.0x (长按加速)" else null
                },
                onBrightnessChange = { newVal ->
                    brightnessLevel = newVal.coerceIn(0.05f, 1.0f)
                    gestureOverlayText = "亮度: ${(brightnessLevel * 100).toInt()}%"
                },
                onVolumeChange = { newVal ->
                    volumeLevel = newVal.coerceIn(0.0f, 1.0f)
                    gestureOverlayText = "音量: ${(volumeLevel * 100).toInt()}%"
                },
                onFullscreenChange = { full ->
                    isFullscreen = full
                    gestureOverlayText = if (full) "已进入全屏模式 (下滑退出)" else "已退出全屏模式"
                },
                onGestureEnd = { gestureOverlayText = null },
                onToggleDanmaku = { danmakuEnabled = !danmakuEnabled },
                onOpenPlayerSettings = { showPlayerSettingsSheet.value = true },
                onDanmakuClick = { dm ->
                    isPlaying = false
                    selectedDanmakuForAction.value = dm
                }
            )

            sponsorBlockSkippedNotice?.let { notice ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 6.dp),
                    onClick = { sponsorBlockSkippedNotice = null }
                ) {
                    Text(
                        text = notice,
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
                    )
                }
            }

            // 2. Detail Sub-Navigation Tabs: 简介与选集 vs 评论区 (含楼中楼)
            val tabs = listOf("视频简介与分P", "评论与楼中楼 (368)")
            Box(modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) {
                TabRowWithContour(
                    tabs = tabs,
                    selectedTabIndex = detailTabIndex,
                    onTabSelected = { detailTabIndex = it }
                )
            }

            when (detailTabIndex) {
                0 -> VideoMetadataAndEpisodesSection(
                    title = title,
                    author = author,
                    bvid = bvid,
                    selectedQuality = selectedQuality,
                    selectedAudioQuality = selectedAudioQuality,
                    selectedCodec = selectedCodec,
                    liked = liked,
                    likeCount = likeCount,
                    coinedCount = coinedCount,
                    favorited = favorited,
                    episodes = episodes,
                    currentPartIndex = currentPartIndex,
                    onLikeClick = {
                        liked = !liked
                        likeCount += if (liked) 1 else -1
                    },
                    onCoinClick = {
                        if (coinedCount < 2) coinedCount += 1
                    },
                    onFavClick = { favorited = !favorited },
                    onTripleAction = {
                        if (!liked) {
                            liked = true
                            likeCount += 1
                        }
                        coinedCount = 2
                        favorited = true
                        gestureOverlayText = "已触发一键三连（点赞 + 投2币 + 收藏）"
                    },
                    onSelectEpisode = { idx ->
                        currentPartIndex = idx
                        durationMs = episodes[idx].durationMs
                        currentPosMs = 0L
                    },
                    onOpenStreamSettings = { showPlayerSettingsSheet.value = true },
                    onRelatedVideoClick = onRelatedVideoClick,
                    onBack = onBack
                )
                1 -> CommentSectionMiuix(bvid = bvid)
            }
        }
    }

    // Click Danmaku Hover Action Dialog (点赞 / 复制 / 举报)
    OverlayDialog(
        show = selectedDanmakuForAction.value != null,
        title = "弹幕互动与管理",
        summary = selectedDanmakuForAction.value?.text ?: "",
        onDismissRequest = {
            selectedDanmakuForAction.value = null
            isPlaying = true
        }
    ) {
        val dm = selectedDanmakuForAction.value
        if (dm != null) {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(text = "发送时间: ${formatDurationMs(dm.timeMs.toLong())} · UID哈希: 0x${dm.uidHash.toString(16)}")
                ArrowPreference(
                    title = "点赞该弹幕 (+${dm.likes + 1})",
                    summary = "支持优质高能弹幕",
                    onClick = {
                        selectedDanmakuForAction.value = null
                        isPlaying = true
                    }
                )
                ArrowPreference(
                    title = "复制弹幕文本",
                    summary = "复制到系统剪贴板",
                    onClick = {
                        selectedDanmakuForAction.value = null
                        isPlaying = true
                    }
                )
                ArrowPreference(
                    title = "屏蔽发送者并举报弹幕",
                    summary = "加入本地 FNV-1a 汇编黑名单过滤表",
                    onClick = {
                        selectedDanmakuForAction.value = null
                        isPlaying = true
                    }
                )
            }
        }
    }

    // Player Settings BottomSheet (倍速 / 画质 / 音质 / 解码格式 / 画面比例)
    PlayerSettingsBottomSheet(
        show = showPlayerSettingsSheet,
        playbackSpeed = playbackSpeed,
        selectedQuality = selectedQuality,
        selectedAudioQuality = selectedAudioQuality,
        selectedCodec = selectedCodec,
        selectedAspectRatio = selectedAspectRatio,
        onSpeedSelect = { playbackSpeed = it },
        onQualitySelect = { selectedQuality = it },
        onAudioSelect = { selectedAudioQuality = it },
        onCodecSelect = { selectedCodec = it },
        onAspectSelect = { selectedAspectRatio = it }
    )
}

@Composable
fun VideoPlayerMiuixBox(
    bvid: String,
    partTitle: String,
    isPlaying: Boolean,
    isFullscreen: Boolean,
    currentPosMs: Long,
    durationMs: Long,
    effectiveSpeed: Float,
    isLongPress2x: Boolean,
    brightness: Float,
    volume: Float,
    selectedQuality: String,
    selectedCodec: String,
    danmakuEnabled: Boolean,
    activeDanmakuTracks: List<Pair<DanmakuItem, Int>>,
    highEnergyCurve: FloatArray,
    gestureOverlayText: String?,
    onTogglePlay: () -> Unit,
    onSeekTo: (Long) -> Unit,
    onLongPress2xChange: (Boolean) -> Unit,
    onBrightnessChange: (Float) -> Unit,
    onVolumeChange: (Float) -> Unit,
    onFullscreenChange: (Boolean) -> Unit,
    onGestureEnd: () -> Unit,
    onToggleDanmaku: () -> Unit,
    onOpenPlayerSettings: () -> Unit,
    onDanmakuClick: (DanmakuItem) -> Unit
) {
    var viewportWidthPx by remember { mutableIntStateOf(1080) }
    var viewportHeightPx by remember { mutableIntStateOf(608) }
    var accumulatedDragX by remember { mutableFloatStateOf(0f) }
    var accumulatedDragY by remember { mutableFloatStateOf(0f) }

    Column(modifier = Modifier.fillMaxWidth()) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .aspectRatio(if (isFullscreen) 18f / 9f else 16f / 9f)
                .background(Color(0xFF10131A))
                .onSizeChanged { size ->
                    viewportWidthPx = size.width.coerceAtLeast(1)
                    viewportHeightPx = size.height.coerceAtLeast(1)
                }
                // Tap & Long-press Gestures: Double-tap left (-10s), center (play/pause), right (+10s); Long-press 2.0x
                .pointerInput(currentPosMs, durationMs) {
                    detectTapGestures(
                        onDoubleTap = { offset ->
                            val third = viewportWidthPx / 3f
                            when {
                                offset.x < third -> onSeekTo(currentPosMs - 10_000L)
                                offset.x > third * 2f -> onSeekTo(currentPosMs + 10_000L)
                                else -> onTogglePlay()
                            }
                        },
                        onLongPress = {
                            onLongPress2xChange(true)
                        },
                        onPress = {
                            tryAwaitRelease()
                            if (isLongPress2x) {
                                onLongPress2xChange(false)
                            }
                        }
                    )
                }
                // Drag Gestures: Horizontal scrub (via ARM64 assembly) & Vertical Brightness/Volume/Fullscreen
                .pointerInput(currentPosMs, durationMs, brightness, volume, isFullscreen) {
                    detectDragGestures(
                        onDragStart = {
                            accumulatedDragX = 0f
                            accumulatedDragY = 0f
                        },
                        onDragEnd = {
                            // Vertical swipe threshold for entering/exiting fullscreen
                            if (abs(accumulatedDragY) > viewportHeightPx * 0.42f && abs(accumulatedDragY) > abs(accumulatedDragX)) {
                                if (accumulatedDragY < 0 && !isFullscreen) {
                                    onFullscreenChange(true)
                                } else if (accumulatedDragY > 0 && isFullscreen) {
                                    onFullscreenChange(false)
                                }
                            }
                            onGestureEnd()
                        },
                        onDragCancel = { onGestureEnd() },
                        onDrag = { change, dragAmount ->
                            change.consume()
                            accumulatedDragX += dragAmount.x
                            accumulatedDragY += dragAmount.y

                            if (abs(accumulatedDragX) > abs(accumulatedDragY)) {
                                val targetMs = PiliAsmCore.safeComputeGestureSeekMs(
                                    currentPosMs = currentPosMs,
                                    durationMs = durationMs,
                                    dragDeltaPx = dragAmount.x.toInt(),
                                    viewportWidthPx = viewportWidthPx
                                )
                                onSeekTo(targetMs)
                            } else {
                                val deltaRatio = -dragAmount.y / viewportHeightPx.toFloat()
                                if (change.position.x < viewportWidthPx / 2f) {
                                    onBrightnessChange(brightness + deltaRatio)
                                } else {
                                    onVolumeChange(volume + deltaRatio)
                                }
                            }
                        }
                    )
                }
        ) {
            // Top bar overlay inside Video Player
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = partTitle,
                    color = Color.White
                )
                Text(
                    text = "$selectedQuality · $selectedCodec · ${effectiveSpeed}x",
                    color = Color(0xFF90CAF9),
                    modifier = Modifier.clickable { onOpenPlayerSettings() }
                )
            }

            // Danmaku Track Overlay (ARM64 NEON Filtered & Collision-Free Tracks)
            if (danmakuEnabled) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 36.dp, start = 12.dp, end = 12.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    activeDanmakuTracks.forEach { (dm, trackIdx) ->
                        Text(
                            text = "[轨道${trackIdx + 1}] ${dm.text}",
                            color = if (dm.isVipColor) Color(0xFFFF80AB) else Color(0xE6FFFFFF),
                            modifier = Modifier.clickable { onDanmakuClick(dm) }
                        )
                    }
                }
            }

            // Center Status / Gesture Feedback Badge
            Column(
                modifier = Modifier.align(Alignment.Center),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = gestureOverlayText
                        ?: if (isPlaying) "正在播放 ($bvid)" else "已暂停 (双击播放/快进 · 长按2倍速)",
                    color = Color.White
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "${formatDurationMs(currentPosMs)} / ${formatDurationMs(durationMs)} · 亮度 ${(brightness * 100).toInt()}% · 音量 ${(volume * 100).toInt()}%",
                    color = Color(0xFFB0BEC5)
                )
            }

            // Bottom High-Energy Progress Curve Canvas Overlay
            Canvas(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(28.dp)
                    .align(Alignment.BottomCenter)
            ) {
                if (highEnergyCurve.size >= 2) {
                    val path = Path()
                    val stepX = size.width / (highEnergyCurve.size - 1).toFloat()
                    highEnergyCurve.forEachIndexed { i, normVal ->
                        val x = i * stepX
                        val y = size.height - (normVal * size.height * 0.85f)
                        if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
                    }
                    drawPath(
                        path = path,
                        color = Color(0xCCFF7043),
                        style = Stroke(width = 2.5.dp.toPx())
                    )
                    // Playhead progress marker
                    val progressX = (currentPosMs.toFloat() / durationMs.coerceAtLeast(1L).toFloat()) * size.width
                    drawLine(
                        color = Color(0xFF64B5F6),
                        start = Offset(progressX, 0f),
                        end = Offset(progressX, size.height),
                        strokeWidth = 3.dp.toPx()
                    )
                }
            }
        }

        // Player Control Bar below video surface
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 8.dp)
        ) {
            Slider(
                progress = (currentPosMs.toFloat() / durationMs.coerceAtLeast(1L).toFloat()).coerceIn(0f, 1f),
                onProgressChange = { ratio ->
                    onSeekTo((ratio * durationMs).toLong())
                },
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(modifier = Modifier.height(6.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    TextButton(
                        text = if (isPlaying) "暂停" else "播放",
                        onClick = onTogglePlay
                    )
                    TextButton(
                        text = if (danmakuEnabled) "弹幕: 开" else "弹幕: 关",
                        onClick = onToggleDanmaku
                    )
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    TextButton(
                        text = "${effectiveSpeed}x / 画质设置",
                        onClick = onOpenPlayerSettings
                    )
                    TextButton(
                        text = if (isFullscreen) "退出全屏" else "全屏",
                        onClick = { onFullscreenChange(!isFullscreen) }
                    )
                }
            }
        }
    }
}

@Composable
fun VideoMetadataAndEpisodesSection(
    title: String,
    author: String,
    bvid: String,
    selectedQuality: String,
    selectedAudioQuality: String,
    selectedCodec: String,
    liked: Boolean,
    likeCount: Int,
    coinedCount: Int,
    favorited: Boolean,
    episodes: List<VideoEpisodePart>,
    currentPartIndex: Int,
    onLikeClick: () -> Unit,
    onCoinClick: () -> Unit,
    onFavClick: () -> Unit,
    onTripleAction: () -> Unit,
    onSelectEpisode: (Int) -> Unit,
    onOpenStreamSettings: () -> Unit,
    onRelatedVideoClick: (VideoCardItem) -> Unit,
    onBack: () -> Unit
) {
    val relatedVideos = remember(bvid) {
        listOf(
            VideoCardItem("BV1rel101", "深入理解 Android NDK 与 AArch64 NEON 寄存器优化", "底层架构实验室", "19.4万观看", "16:40", 1_000_000L),
            VideoCardItem("BV1rel102", "Compose Multiplatform 1.12 与 Miuix 组件库实战指南", "KMP开发者", "11.2万观看", "12:15", 735_000L)
        )
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Video Title, UP Info & Stream Specs
        item {
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(text = title)
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(text = "UP主: $author · $bvid")
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(text = "当前流媒体: $selectedQuality · $selectedAudioQuality · $selectedCodec")
                }
            }
        }

        // Like / Coin / Favorite / Triple Combo Action Row
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                TextButton(
                    text = if (liked) "已赞 ($likeCount)" else "点赞 ($likeCount)",
                    onClick = onLikeClick,
                    modifier = Modifier.weight(1f)
                )
                TextButton(
                    text = if (coinedCount > 0) "已投币 ($coinedCount)" else "投币",
                    onClick = onCoinClick,
                    modifier = Modifier.weight(1f)
                )
                TextButton(
                    text = if (favorited) "已收藏" else "收藏",
                    onClick = onFavClick,
                    modifier = Modifier.weight(1f)
                )
                Button(
                    onClick = onTripleAction,
                    modifier = Modifier.weight(1.2f)
                ) {
                    Text(text = "一键三连")
                }
            }
        }

        // Multi-part Episode Selector (视频选集分P切换)
        item {
            SmallTitle(text = "视频选集 (${currentPartIndex + 1}/${episodes.size})")
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                contentPadding = PaddingValues(vertical = 4.dp)
            ) {
                itemsIndexed(episodes) { idx, ep ->
                    Card(
                        modifier = Modifier.width(220.dp),
                        onClick = { onSelectEpisode(idx) }
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text(
                                text = if (idx == currentPartIndex) "▶ ${ep.partTitle}" else ep.partTitle
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(text = "时长: ${formatDurationMs(ep.durationMs)}")
                        }
                    }
                }
            }
        }

        // Stream & Player Preset Entry
        item {
            Card(modifier = Modifier.fillMaxWidth()) {
                ArrowPreference(
                    title = "画质、音质、解码器与倍速预设",
                    summary = "$selectedQuality · $selectedAudioQuality · $selectedCodec",
                    onClick = onOpenStreamSettings
                )
                ArrowPreference(
                    title = "返回上一页",
                    summary = "退出当前视频详情页",
                    onClick = onBack
                )
            }
        }

        // Related Videos List
        item {
            SmallTitle(text = "相关推荐视频")
        }
        items(relatedVideos, key = { it.bvid }) { item ->
            Card(
                modifier = Modifier.fillMaxWidth(),
                onClick = { onRelatedVideoClick(item) }
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(text = item.title)
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(text = "UP: ${item.upName} · ${item.viewsText} · ${item.durationText}")
                }
            }
        }
    }
}

@Composable
fun PlayerSettingsBottomSheet(
    show: MutableState<Boolean>,
    playbackSpeed: Float,
    selectedQuality: String,
    selectedAudioQuality: String,
    selectedCodec: String,
    selectedAspectRatio: String,
    onSpeedSelect: (Float) -> Unit,
    onQualitySelect: (String) -> Unit,
    onAudioSelect: (String) -> Unit,
    onCodecSelect: (String) -> Unit,
    onAspectSelect: (String) -> Unit
) {
    OverlayBottomSheet(
        show = show.value,
        title = "播放与流媒体参数设置",
        onDismissRequest = { show.value = false }
    ) {
        LazyColumn(
            modifier = Modifier
                .fillMaxWidth()
                .height(420.dp),
            contentPadding = PaddingValues(bottom = 24.dp)
        ) {
            item {
                SmallTitle(text = "播放倍速 (长按画面可临时 2.0x)")
                val speeds = listOf(0.5f, 0.75f, 1.0f, 1.25f, 1.5f, 2.0f)
                speeds.forEach { spd ->
                    RadioButtonPreference(
                        title = "${spd}x 倍速",
                        selected = playbackSpeed == spd,
                        onClick = { onSpeedSelect(spd) }
                    )
                }
            }
            item {
                SmallTitle(text = "视频清晰度 (官方标准流)")
                val qualities = listOf("1080P 60帧", "1080P 高清", "720P 高清", "480P 清晰")
                qualities.forEach { q ->
                    RadioButtonPreference(
                        title = q,
                        selected = selectedQuality == q,
                        onClick = { onQualitySelect(q) }
                    )
                }
            }
            item {
                SmallTitle(text = "音质选择")
                val audios = listOf("Hi-Res 无损", "杜比全景声", "192K 高品质", "132K 标准")
                audios.forEach { audio ->
                    RadioButtonPreference(
                        title = audio,
                        selected = selectedAudioQuality == audio,
                        onClick = { onAudioSelect(audio) }
                    )
                }
            }
            item {
                SmallTitle(text = "解码格式与画面比例")
                val codecs = listOf("HEVC (H.265)", "AV1", "AVC (H.264)")
                codecs.forEach { codec ->
                    RadioButtonPreference(
                        title = "解码器: $codec",
                        selected = selectedCodec == codec,
                        onClick = { onCodecSelect(codec) }
                    )
                }
                val ratios = listOf("16:9 适应", "高度填充", "宽度适应", "4:3 经典")
                ratios.forEach { ratio ->
                    RadioButtonPreference(
                        title = "画面比例: $ratio",
                        selected = selectedAspectRatio == ratio,
                        onClick = { onAspectSelect(ratio) }
                    )
                }
            }
        }
    }
}

/* ============================================================================
 * Module 2: Comments & Floor-in-Floor (评论排序、二楼楼中楼查看对话与回复)
 * ============================================================================ */

@Composable
fun CommentSectionMiuix(bvid: String) {
    var sortByHot by remember { mutableStateOf(true) }
    var newCommentText by remember { mutableStateOf("") }
    val activeSubReplyParent = remember { mutableStateOf<CommentItem?>(null) }

    val commentList = remember(bvid) {
        mutableStateListOf(
            CommentItem(
                rpid = 9001L,
                userName = "底层架构实验室",
                level = 6,
                isUp = true,
                isPinned = true,
                content = "【置顶】本项目采用 Kotlin Multiplatform (Miuix UI) + Android NDK arm64-v8a 汇编混合编译，源码仓库已配置好 GitHub Actions 自动构建 APK。",
                timeText = "2小时前",
                timestampSec = 1760940000L,
                likes = 1280,
                imageNoteTag = "附：ARM64 NEON 寄存器吞吐量对比图.png",
                subReplies = listOf(
                    SubReplyItem(9101L, "移动端优化狂魔", 6, "实测在骁龙 8 Elite 上弹幕过滤耗时不到 0.03ms！", "1小时前", 86),
                    SubReplyItem(9102L, "Compose爱好者", 5, "Miuix 0.9.4 的 NavDisplay 和丝滑圆角体验太棒了", "45分钟前", 42, replyToUser = "移动端优化狂魔")
                )
            ),
            CommentItem(
                rpid = 9002L,
                userName = "音视频开发者",
                level = 6,
                isUp = false,
                isPinned = false,
                content = "手势交互很完整，左侧上下滑调亮度、右侧调音量、水平滑带帧预览毫秒计算、上滑直接进全屏。",
                timeText = "50分钟前",
                timestampSec = 1760944200L,
                likes = 342,
                subReplies = listOf(
                    SubReplyItem(9201L, "内核观察员", 5, "水平滑动的毫秒偏移和边界截断也是用 AArch64 汇编算的", "30分钟前", 19)
                )
            ),
            CommentItem(
                rpid = 9003L,
                userName = "KMP探索者",
                level = 5,
                isUp = false,
                isPinned = false,
                content = "刚刚发布的最新评论，测试一下按时间排序和按热度排序的 ARM64 Shellsort 切换速度！",
                timeText = "刚刚",
                timestampSec = 1760947000L,
                likes = 18
            )
        )
    }

    val sortedComments = remember(commentList.size, sortByHot) {
        PiliAsmCore.safeSortComments(commentList.toList(), sortByHot = sortByHot)
    }

    Column(modifier = Modifier.fillMaxSize()) {
        // Sort Header & Reply Bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(text = if (sortByHot) "按热度排序 (ARM64 汇编加速)" else "按时间排序 (ARM64 汇编加速)")
            TextButton(
                text = if (sortByHot) "切换为按时间" else "切换为按热度",
                onClick = { sortByHot = !sortByHot }
            )
        }

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(modifier = Modifier.weight(1f)) {
                InputField(
                    query = newCommentText,
                    onQueryChange = { newCommentText = it },
                    label = "发一条友善的评论 (支持表情/@用户)...",
                    expanded = false,
                    onExpandedChange = {},
                    modifier = Modifier.fillMaxWidth()
                )
            }
            Button(
                onClick = {
                    if (newCommentText.isNotBlank()) {
                        commentList.add(
                            0,
                            CommentItem(
                                rpid = System.currentTimeMillis(),
                                userName = "当前登录用户",
                                level = 6,
                                isUp = false,
                                isPinned = false,
                                content = newCommentText,
                                timeText = "刚刚",
                                timestampSec = System.currentTimeMillis() / 1000L,
                                likes = 1
                            )
                        )
                        newCommentText = ""
                    }
                }
            ) {
                Text(text = "发布")
            }
        }

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(sortedComments, key = { it.rpid }) { comment ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    onClick = {
                        if (comment.subReplies.isNotEmpty()) {
                            activeSubReplyParent.value = comment
                        }
                    }
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            val badge = buildString {
                                if (comment.isPinned) append("[置顶] ")
                                append(comment.userName)
                                append(" · Lv${comment.level}")
                                if (comment.isUp) append(" [UP主]")
                            }
                            Text(text = badge)
                            Text(text = "👍 ${comment.likes}")
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(text = comment.content)

                        comment.imageNoteTag?.let { imgTag ->
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "🖼 [带图评论/笔记] $imgTag (点击查看与保存原图)",
                                color = Color(0xFF42A5F5)
                            )
                        }

                        Spacer(modifier = Modifier.height(6.dp))
                        Text(text = comment.timeText)

                        // Floor-in-floor preview box (评论楼中楼预览)
                        if (comment.subReplies.isNotEmpty()) {
                            Spacer(modifier = Modifier.height(8.dp))
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(Color(0x14888888))
                                    .padding(10.dp),
                                verticalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                comment.subReplies.take(2).forEach { sub ->
                                    val prefix = if (sub.replyToUser != null) {
                                        "${sub.userName} 回复 @${sub.replyToUser}: "
                                    } else {
                                        "${sub.userName}: "
                                    }
                                    Text(text = "$prefix${sub.content}")
                                }
                                Text(
                                    text = "共 ${comment.subReplies.size} 条回复，点击查看楼中楼完整对话 >",
                                    color = Color(0xFF42A5F5)
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    // Floor-in-Floor Sub-Reply BottomSheet (二楼评论楼中楼查看对话与回复)
    OverlayBottomSheet(
        show = activeSubReplyParent.value != null,
        title = "评论详情与楼中楼对话",
        onDismissRequest = { activeSubReplyParent.value = null }
    ) {
        val parent = activeSubReplyParent.value
        var subReplyInput by remember { mutableStateOf("") }
        if (parent != null) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(420.dp)
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Card(modifier = Modifier.fillMaxWidth()) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text(text = "楼主: ${parent.userName} (Lv${parent.level})")
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(text = parent.content)
                    }
                }
                SmallTitle(text = "楼中楼回复 (${parent.subReplies.size})")
                LazyColumn(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(parent.subReplies, key = { it.rpid }) { sub ->
                        Card(modifier = Modifier.fillMaxWidth()) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Text(
                                    text = if (sub.replyToUser != null) {
                                        "${sub.userName} (Lv${sub.level}) 回复 @${sub.replyToUser}"
                                    } else {
                                        "${sub.userName} (Lv${sub.level})"
                                    }
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(text = sub.content)
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(text = "${sub.timeText} · 👍 ${sub.likes}")
                            }
                        }
                    }
                }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(modifier = Modifier.weight(1f)) {
                        InputField(
                            query = subReplyInput,
                            onQueryChange = { subReplyInput = it },
                            label = "回复层主 @${parent.userName}...",
                            expanded = false,
                            onExpandedChange = {},
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                    Button(onClick = { subReplyInput = "" }) {
                        Text(text = "发送")
                    }
                }
            }
        }
    }
}

/* ============================================================================
 * Module 3: Dynamic Feed (动态分类查看：全部 / 投稿 / 番剧 / 图文动态评论与转发)
 * ============================================================================ */

@Composable
fun DynamicFeedScreen(
    contentPadding: PaddingValues,
    onVideoClick: (VideoCardItem) -> Unit
) {
    var selectedCategoryTab by remember { mutableIntStateOf(0) }
    val categories = listOf("全部动态", "视频投稿", "追番/番剧", "图文话题")
    val activeDynamicForComments = remember { mutableStateOf<DynamicPostItem?>(null) }
    val showPublishDynamicDialog = remember { mutableStateOf(false) }

    val allDynamics = remember {
        listOf(
            DynamicPostItem(
                dynId = "dyn_1001",
                category = "video",
                authorName = "底层架构实验室",
                pubTimeText = "35分钟前 · 发布了视频投稿",
                topicTag = "#ARM64汇编与KMP开发#",
                contentText = "我们将 PiliPlus 的高频计算模块（WBI 签名置换、弹幕时间窗 NEON 向量过滤、高能进度条峰值归一化、评论区排序）全部用 AArch64 汇编写成了原生库，UI 采用 Miuix 构建！",
                attachedVideo = VideoCardItem(
                    bvid = "BV1xx411c7mD",
                    title = "ARM64 汇编与 Kotlin Multiplatform 混合架构解析",
                    upName = "底层架构实验室",
                    viewsText = "12.8万观看",
                    durationText = "14:20"
                ),
                likes = 640,
                reposts = 88,
                comments = listOf(
                    CommentItem(
                        rpid = 8001L,
                        userName = "极客玩家",
                        level = 6,
                        isUp = false,
                        isPinned = false,
                        content = "直接扔进 GitHub Actions 就能编译出 arm64-v8a 的安装包，太方便了！",
                        timeText = "20分钟前",
                        timestampSec = 1760946000L,
                        likes = 49
                    )
                )
            ),
            DynamicPostItem(
                dynId = "dyn_1002",
                category = "bangumi",
                authorName = "番剧连载放送局",
                pubTimeText = "2小时前 · 更新了番剧剧集",
                topicTag = "#十月新番导视#",
                contentText = "《剑来·第二季》第 12 集现已上线！支持自动跳过片头片尾与杜比全景声。",
                attachedVideo = VideoCardItem(
                    bvid = "BV1bangumi01",
                    title = "【番剧】全集高帧率连载正片与片头片尾智能跳过",
                    upName = "番剧连载放送局",
                    viewsText = "185.4万观看",
                    durationText = "24:10",
                    durationMs = 1_450_000L
                ),
                likes = 2410,
                reposts = 312
            ),
            DynamicPostItem(
                dynId = "dyn_1003",
                category = "article",
                authorName = "KMP开发者",
                pubTimeText = "4小时前 · 发布了图文动态",
                topicTag = "#ComposeMiuixUI#",
                contentText = "分享一组使用 Miuix 0.9.4 组件库制作的超椭圆圆角（Squircle）与渐进式背景模糊（Progressive Blur）实机截图，支持亮暗色主题跟随系统。",
                imageCount = 4,
                likes = 420,
                reposts = 45
            )
        )
    }

    val filteredDynamics = remember(selectedCategoryTab, allDynamics) {
        when (selectedCategoryTab) {
            1 -> allDynamics.filter { it.category == "video" }
            2 -> allDynamics.filter { it.category == "bangumi" }
            3 -> allDynamics.filter { it.category == "article" }
            else -> allDynamics
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(contentPadding)
    ) {
        // Top Category Filter & Publish Dynamic Button
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(modifier = Modifier.weight(1f)) {
                TabRowWithContour(
                    tabs = categories,
                    selectedTabIndex = selectedCategoryTab,
                    onTabSelected = { selectedCategoryTab = it }
                )
            }
            Spacer(modifier = Modifier.width(8.dp))
            Button(onClick = { showPublishDynamicDialog.value = true }) {
                Text(text = "发动态")
            }
        }

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(filteredDynamics, key = { it.dynId }) { post ->
                Card(modifier = Modifier.fillMaxWidth()) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(text = "${post.authorName} · ${post.pubTimeText}")
                        post.topicTag?.let { tag ->
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(text = tag, color = Color(0xFF42A5F5))
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(text = post.contentText)

                        // Attached Video Card inside Dynamic Post
                        post.attachedVideo?.let { video ->
                            Spacer(modifier = Modifier.height(10.dp))
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                onClick = { onVideoClick(video) }
                            ) {
                                Column(modifier = Modifier.padding(12.dp)) {
                                    Text(text = "🎬 ${video.title}")
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(text = "${video.viewsText} · 时长 ${video.durationText} (点击立即播放)")
                                }
                            }
                        }

                        if (post.imageCount > 0) {
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = "🖼 包含 ${post.imageCount} 张高清图文附件 (支持手势缩放与保存)",
                                color = Color(0xFF64B5F6)
                            )
                        }

                        Spacer(modifier = Modifier.height(10.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            TextButton(
                                text = "转发 (${post.reposts})",
                                onClick = {}
                            )
                            TextButton(
                                text = "评论 (${post.comments.size})",
                                onClick = { activeDynamicForComments.value = post }
                            )
                            TextButton(
                                text = "点赞 (${post.likes})",
                                onClick = {}
                            )
                        }
                    }
                }
            }
        }
    }

    // Dynamic Comments & Reply BottomSheet (动态评论查看与回复)
    OverlayBottomSheet(
        show = activeDynamicForComments.value != null,
        title = "动态评论与回复",
        onDismissRequest = { activeDynamicForComments.value = null }
    ) {
        val dyn = activeDynamicForComments.value
        var dynReplyInput by remember { mutableStateOf("") }
        if (dyn != null) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(360.dp)
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(text = "${dyn.authorName}: ${dyn.contentText}")
                SmallTitle(text = "全部动态评论 (${dyn.comments.size})")
                LazyColumn(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(dyn.comments, key = { it.rpid }) { c ->
                        Card(modifier = Modifier.fillMaxWidth()) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Text(text = "${c.userName} (Lv${c.level}) · 👍 ${c.likes}")
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(text = c.content)
                            }
                        }
                    }
                }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(modifier = Modifier.weight(1f)) {
                        InputField(
                            query = dynReplyInput,
                            onQueryChange = { dynReplyInput = it },
                            label = "回复该条动态 (支持富文本/表情/@用户)...",
                            expanded = false,
                            onExpandedChange = {},
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                    Button(onClick = { dynReplyInput = "" }) {
                        Text(text = "发送")
                    }
                }
            }
        }
    }

    // Publish / Edit Dynamic Dialog
    OverlayDialog(
        show = showPublishDynamicDialog.value,
        title = "发布图文/话题动态",
        summary = "支持富文本编辑、话题标签、发起投票及防剧透折叠",
        onDismissRequest = { showPublishDynamicDialog.value = false }
    ) {
        var draftText by remember { mutableStateOf("") }
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            InputField(
                query = draftText,
                onQueryChange = { draftText = it },
                label = "分享你的动态内容 (@用户 / #话题#)...",
                expanded = false,
                onExpandedChange = {},
                modifier = Modifier.fillMaxWidth()
            )
            Button(
                onClick = { showPublishDynamicDialog.value = false },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(text = "立即发布")
            }
        }
    }
}

/* ============================================================================
 * Recommend Feed, Hot/Bangumi & Settings Screens
 * ============================================================================ */

@Composable
fun RecommendFeedScreen(
    contentPadding: PaddingValues,
    searchQuery: String,
    onSearchQueryChange: (String) -> Unit,
    onVideoClick: (VideoCardItem) -> Unit
) {
    var isRefreshing by remember { mutableStateOf(false) }
    val pullToRefreshState = rememberPullToRefreshState(refreshThreshold = 0.25f)

    val sampleVideos = remember {
        listOf(
            VideoCardItem("BV1xx411c7mD", "ARM64 汇编与 Kotlin Multiplatform 混合架构解析", "底层架构实验室", "12.8万观看", "14:20", 860_000L),
            VideoCardItem("BV1yy411c7mE", "Compose Miuix UI 组件库跨平台设计实践", "KMP开发者", "8.4万观看", "09:45", 585_000L),
            VideoCardItem("BV1zz411c7mF", "高帧率弹幕渲染引擎与 NEON SIMD 指令优化", "音视频技术栈", "23.1万观看", "18:12", 1_092_000L)
        )
    }

    PullToRefresh(
        isRefreshing = isRefreshing,
        onRefresh = { isRefreshing = false },
        pullToRefreshState = pullToRefreshState,
        modifier = Modifier
            .fillMaxSize()
            .padding(contentPadding)
    ) {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                InputField(
                    query = searchQuery,
                    onQueryChange = onSearchQueryChange,
                    label = "搜索投稿、番剧、直播或用户...",
                    expanded = false,
                    onExpandedChange = {},
                    modifier = Modifier.fillMaxWidth()
                )
            }

            items(sampleVideos, key = { it.bvid }) { video ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    onClick = { onVideoClick(video) }
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(text = video.title)
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(text = "UP: ${video.upName}")
                            Text(text = "${video.viewsText} · ${video.durationText}")
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun HotAndBangumiScreen(
    contentPadding: PaddingValues,
    onVideoClick: (VideoCardItem) -> Unit
) {
    val hotList = remember {
        listOf(
            VideoCardItem("BV1hot001", "【热门】全站实时热门视频排行总览", "哔哩动态观察", "65.2万观看", "11:08", 668_000L),
            VideoCardItem("BV1hot002", "【番剧】新番连载时间表与追番索引", "番剧导航", "41.0万观看", "24:00", 1_440_000L)
        )
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(contentPadding),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            SmallTitle(text = "全站最热与番剧分区")
        }
        items(hotList, key = { it.bvid }) { item ->
            Card(
                modifier = Modifier.fillMaxWidth(),
                onClick = { onVideoClick(item) }
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(text = item.title)
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(text = "${item.upName} · ${item.viewsText}")
                }
            }
        }
    }
}

@Composable
fun SettingsScreen(contentPadding: PaddingValues) {
    var incognitoMode by remember { mutableStateOf(false) }
    var guestRecommendMode by remember { mutableStateOf(false) }
    var hardwareAccel by remember { mutableStateOf(true) }
    var sponsorBlockEnabled by remember { mutableStateOf(true) }
    var highFrameRate by remember { mutableStateOf(true) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(contentPadding),
        contentPadding = PaddingValues(vertical = 12.dp)
    ) {
        item {
            SmallTitle(text = "隐私与账号模式")
            Card(modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)) {
                SwitchPreference(
                    title = "无痕模式",
                    summary = "播放视频视为未登录，不记录观看历史",
                    checked = incognitoMode,
                    onCheckedChange = { incognitoMode = it }
                )
                SwitchPreference(
                    title = "游客推荐模式",
                    summary = "首页推荐流视为未登录状态获取",
                    checked = guestRecommendMode,
                    onCheckedChange = { guestRecommendMode = it }
                )
            }
        }

        item {
            SmallTitle(text = "播放与弹幕设置 (arm64-v8a 汇编加速)")
            Card(modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)) {
                SwitchPreference(
                    title = "硬件加速解码",
                    summary = "优先启用 MediaCodec / Vulkan 硬件渲染管线",
                    checked = hardwareAccel,
                    onCheckedChange = { hardwareAccel = it }
                )
                SwitchPreference(
                    title = "高帧率渲染模式",
                    summary = "解锁 120Hz 列表滑动与 NEON 高能进度条采样",
                    checked = highFrameRate,
                    onCheckedChange = { highFrameRate = it }
                )
                SwitchPreference(
                    title = "空降助手 (SponsorBlock) 与片头片尾跳过",
                    summary = "自动识别并跳过恰饭片段与番剧片头/片尾",
                    checked = sponsorBlockEnabled,
                    onCheckedChange = { sponsorBlockEnabled = it }
                )
                ArrowPreference(
                    title = "默认画质与解码格式预设",
                    summary = "AVC / HEVC / AV1 · 音质与字幕字号调节",
                    onClick = {}
                )
                ArrowPreference(
                    title = "WebDAV 备份与恢复",
                    summary = "同步本地黑名单、收藏夹排序及播放设置",
                    onClick = {}
                )
            }
        }
    }
}

private fun formatDurationMs(ms: Long): String {
    val totalSec = (ms / 1000L).coerceAtLeast(0L)
    val min = totalSec / 60L
    val sec = totalSec % 60L
    return "${min.toString().padStart(2, '0')}:${sec.toString().padStart(2, '0')}"
}