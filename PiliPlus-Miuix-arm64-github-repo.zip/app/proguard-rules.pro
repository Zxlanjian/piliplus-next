-keepclasseswithmembernames class * {
    native <methods>;
}
-keep class com.piliplus.miuix.PiliAsmCore { *; }
-keep class com.piliplus.miuix.PiliRoute** { *; }
