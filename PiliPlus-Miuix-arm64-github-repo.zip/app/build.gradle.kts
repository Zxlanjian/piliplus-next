plugins {
    id("com.android.application") version "8.7.2"
    kotlin("android") version "2.1.20"
    kotlin("plugin.compose") version "2.1.20"
    kotlin("plugin.serialization") version "2.1.20"
}

android {
    namespace = "com.piliplus.miuix"
    compileSdk = 35
    ndkVersion = "27.2.12479018"

    defaultConfig {
        applicationId = "com.piliplus.miuix"
        minSdk = 24 // Required by Miuix v0.9.4+
        targetSdk = 35
        versionCode = 100
        versionName = "1.0.0-arm64"

        ndk {
            // Only build for Android 64-bit ARM (AArch64)
            abiFilters += listOf("arm64-v8a")
        }

        externalNativeBuild {
            cmake {
                arguments += listOf(
                    "-DANDROID_STL=none",
                    "-DANDROID_ABI=arm64-v8a"
                )
                cFlags += listOf("-O3", "-fvisibility=hidden")
            }
        }
    }

    externalNativeBuild {
        cmake {
            path = file("src/main/cpp/CMakeLists.txt")
            version = "3.22.1"
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
            signingConfig = signingConfigs.getByName("debug") // Replace with release keystore in CI if needed
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_21
        targetCompatibility = JavaVersion.VERSION_21
    }

    kotlinOptions {
        jvmTarget = "21"
    }

    buildFeatures {
        compose = true
    }
}

val miuixVersion = "0.9.4"

dependencies {
    // Compose Multiplatform / AndroidX Compose Foundation & Activity
    implementation("androidx.activity:activity-compose:1.10.1")
    implementation("org.jetbrains.kotlinx:kotlinx-serialization-json:1.8.0")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.10.1")

    // Miuix UI Library for Compose Multiplatform (https://compose-miuix-ui.github.io/miuix/zh_CN/)
    implementation("top.yukonga.miuix.kmp:miuix-ui:$miuixVersion")
    implementation("top.yukonga.miuix.kmp:miuix-nav:$miuixVersion")
    implementation("top.yukonga.miuix.kmp:miuix-preference:$miuixVersion")
    implementation("top.yukonga.miuix.kmp:miuix-blur:$miuixVersion")
    implementation("top.yukonga.miuix.kmp:miuix-squircle:$miuixVersion")
    implementation("top.yukonga.miuix.kmp:miuix-icons:$miuixVersion")

    // Media3 ExoPlayer for hardware-accelerated video decoding on Android
    implementation("androidx.media3:media3-exoplayer:1.5.1")
    implementation("androidx.media3:media3-exoplayer-dash:1.5.1")
    implementation("androidx.media3:media3-ui:1.5.1")
}
